   /* • Crear un array de números enteros con una dimensión de un número de elementos que se pedirá por consola.
    • Pedir cada número por consola.*/

#include <iostream>

using namespace std;


int main()
{
    int cantidad;
    int i;
    cout<<"Cuantos numeros van a insertar: "<<endl;
    cin>>cantidad;
    cout<<"Dime los numeros: "<<endl;
    int numeros[cantidad];
    int numerosDoble[cantidad];
    int sumaArray=0,sumaArrayDoble=0;

    for (i=0;i<cantidad;i++){
        cin>>numeros[i];
        numerosDoble[i] = numeros[i]*2;
        sumaArray+=numeros[i];
        sumaArrayDoble+=numerosDoble[i];
    }

    cout<<"Suma elementos primer array: "<< sumaArray<< endl;
    cout<<"Suma elementos segundo array: "<< sumaArrayDoble<< endl;

    return 0;
}
