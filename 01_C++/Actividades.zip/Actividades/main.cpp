/*
    Crear 2 constructores.
        Uno con los tres valores (titular, saldo e inter�s)
        Uno sin ning�n valor que de como valores por defecto: titular="", saldo=0, inter�s=0

    Establecer todas las propiedades como privadas

    A la hora de asignar un saldo, impedir que sea negativo. Si se le mete un saldo negativo, poner el saldo a -1
    Hacer lo mismo con el inter�s
    */

    #include<iostream>
    #include <iomanip> // redondear a dos los decimales

    using namespace std;

    class CuentaCorriente
    {
        private:
            string titular;
            float saldo;
            float interes;

        public:

        CuentaCorriente() // es un constructor, es un m�todo para instanciar el objeto de la clase, puedes hacer varias versiones llamandose igual por
            {
                setTitular(" ");
                setSaldo(0);
                setInteres(0);
            }

        CuentaCorriente(string ptitular,float psaldo,float pinteres) // es un constructor, es un m�todo para instanciar el objeto de la clase, puedes hacer varias versiones llamandose igual por
        {
            setTitular(ptitular);
            setSaldo(psaldo);
            setInteres(pinteres);
        }


        float getInteresMensual()
        {
            return (saldo*(interes/100))/12;
        }

        float getInteresAnual()
        {
            return saldo*(interes/100);
        }

        string getTitular()
        {
            return titular;
        }

        float getSaldo()
        {
            return saldo;
        }

        float getInteres()
        {
            return interes;
        }

        void setTitular(string ptitular)
        {
            titular=ptitular;
        }

        void modificarSaldo(float pcantidad)
        {
            saldo+=pcantidad;
        }
        void setInteres(float pinteres)
        {
            interes=revisarCantidad(pinteres);
        }

        void setSaldo(float psaldo)
        {
            saldo=revisarCantidad(psaldo);
        }

        float revisarCantidad(float cantidad)
        {
            return (cantidad>=0?cantidad:-1);
        }

        void imprimirDatosCuenta()
        {
            cout<<" Tilular: "<<getTitular()<<" Saldo: "<<getSaldo()<<" Interes: "<<getInteres()<<endl;
        }

    };

    int main()
    {
        CuentaCorriente cta1("Pepe",1000,5);
        CuentaCorriente cta2("Luis",-23,7);
        CuentaCorriente cta3("Lorena",2500,-6);
        CuentaCorriente cta4;

        cta1.imprimirDatosCuenta();
        cta2.imprimirDatosCuenta();
        cta3.imprimirDatosCuenta();
        cta4.imprimirDatosCuenta();




        return 0;
    }
