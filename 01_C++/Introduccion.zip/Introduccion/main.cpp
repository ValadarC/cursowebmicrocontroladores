#include <iostream>

using namespace std;

class Persona {
    private:
        // Propiedades
        string nombre;
        int edad;
        double nota;
        // Propiedades estáticas de clase
        static int personasTotales;
        static double notaMaxima;
    public:

        // Un constructor nos permite construir objetos de forma más fiable y rápida
        // Normalmente, las propiedades serán privadas y el constructor público
        // Un método constructor obliga a tener com nombre el mismo que la clase
        // this-> hace referencia a las propiedades y métodos del objeto que se instancia
        Persona(string nombre, int edad, double nota) {
            this->nombre = nombre;
            this->edad =edad;
            setNota(nota);
            personasTotales++;
        }
        // Los constructores se pueden versionar. Igual la edad no la consideramos importantes. Aquí tenermos una versión del constructor sin la edad

        Persona(string nombre, double nota) {
            this->nombre = nombre;
            this->edad =0;
            setNota(nota);
            personasTotales++;
        }

        // A menudo se suele incluir un constructor sin valores de entrada que da valores por defecto a las propiedades
        Persona() {
            this->nombre = "";
            this->edad =0;
            this->nota=0;
            personasTotales++;
        }


        // Métodos getters y setters

        void setNombre(string nombre){
            this->nombre=nombre;
        }

        string getNombre(){
            return nombre;
        }

        void setEdad(int edad){
            this->edad=edad;
        }

        int getEdad(){
            return edad;
        }

        void setNota(double nota){
           if (nota >=0 && nota <=10){
                this->nota=nota;
                notaMaxima = nota > notaMaxima? nota: notaMaxima;
            } else{
                this->nota = -1;
            }
        }

        double getNota(){
            return nota;
        }

        bool apto(){
            return this->nota>=5? true:false;
        }

        bool aptoNotaDeCorte(double notaCorte){
            return this->nota>=notaCorte? true:false;
        }

        int getPersonasTotales(){
            return personasTotales;
        }

        double getNotaMaxima(){
            return notaMaxima;
        }
};

// Debemos inicializar las propiedades estáticas
int Persona::personasTotales =0;
double Persona::notaMaxima =0;

int main(){
    // Objeto de clase Persona utilizando el constructor
    Persona amigo("Pedro",30,6);
    Persona amiga("Ana",6);

    cout << amigo.getNombre() << endl;
    cout << amiga.getNombre() << endl;
    cout << amigo.getPersonasTotales() << endl;
    cout << amiga.getPersonasTotales() << endl;
    cout << amigo.getNotaMaxima() << endl;
    cout << amiga.getPersonasTotales() << endl;

    return 0;
}
