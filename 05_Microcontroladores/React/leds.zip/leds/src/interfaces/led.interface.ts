export interface ILed {
    estado: boolean;
    hora: Date;
}