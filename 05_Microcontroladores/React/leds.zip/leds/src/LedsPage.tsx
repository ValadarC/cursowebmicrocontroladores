import { useEffect, useState } from 'react';
import {
  DocumentData,
  QueryDocumentSnapshot,
  Timestamp,
  collection,
  onSnapshot,
  orderBy,
  query
} from 'firebase/firestore';
import { db } from './firebase/firebaseConfig';

export const LedsPage = () => {
  const [estado, setEstado] = useState<string>('0');
  const [fecha, setFecha] = useState<string>('');

  useEffect(() => {
    const q = query(collection(db, 'luces'), orderBy('hora', 'desc'));
    onSnapshot(q, (data) => {
      updateEstadoLuz(data.docs[0]);
    });
  }, []);

  const updateEstadoLuz = (estadoLuz: QueryDocumentSnapshot<DocumentData>) => {
    const estado = estadoLuz.data().estado;
    console.log(estado)
    const timeStamp = new Timestamp(estadoLuz.data().hora.seconds, estadoLuz.data().hora.nanoseconds);
    const fecha = `${timeStamp.toDate().toLocaleDateString()}-${timeStamp.toDate().toLocaleTimeString()}`;
    setEstado(estado);
    setFecha(fecha);
  };

  return (
    <main className="container">
      <h1 className="display-1">Estado led Arduino</h1>
      <hr />
      <div className="row">
        <div className="col">
          {estado === '0' && <i className="fa-solid fa-lightbulb" style={{ fontSize: 'xx-large' }}></i>}
          {estado === '1' && <i className="fa-solid fa-lightbulb" style={{ fontSize: 'xx-large', color: 'red' }}></i>}
        </div>
        <div className="col">
          <p className="lead">{fecha}</p>
        </div>
        <hr className="mt-4" />
      </div>

      <footer>&copy; Juan Luis Ochoa - 2024</footer>
    </main>
  );
};