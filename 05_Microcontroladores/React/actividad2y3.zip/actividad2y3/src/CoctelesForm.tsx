import { ChangeEvent, FormEvent, useState } from 'react';
import { ICoctel, IDrink } from './interfaces/coctel.interface';
import { CardCoctel } from './components/CardCoctel';


export const CoctelesForm = () => {
  const [ingrediente, setIngrediente] = useState<string>('');
  const [coctelesDeGinebra, setCoctelesDeGinebra] = useState<IDrink[]>([]);
  const [status, setStatus] = useState<number>(0); 
  const [errorFetch, setErrorFetch] = useState<boolean>(false); 
  
  const fetchCocteles = async (): Promise<void> => {
    try {
      const data = await fetch(`https://www.thecocktaildb.com/api/json/v1/1/filter.php?i=${ingrediente}`);
      const json: ICoctel = await data.json();
      setStatus(data.status);
      setCoctelesDeGinebra(json.drinks);
      console.log(json);
      setErrorFetch(false);
    } catch (e) {
      setErrorFetch(true);
    }
  };

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    fetchCocteles();
  };

  const onChangeIngrediente = (e: ChangeEvent<HTMLInputElement>) => {
    setIngrediente(e.target.value);
  };

  
  return (
    <>
      <h1>Cocteles</h1>
      <hr />
      <form onSubmit={onSubmit}>
      <div className="form-group">
        <label htmlFor="ingrediente">Ingrediente</label>
        <input className="form-control" id="ingrediente" type="text" value={ingrediente} onChange={onChangeIngrediente} />
        {/* useState nos permite controlar en todo momento el valor del email y del password para, por ejemplo, sacar mensajes */}
        {ingrediente.trim() === '' && <small>Ingrediente obligatorio</small>}
      </div>
      <button className="btn btn-success" type="submit" disabled={ingrediente.trim() === ''}>
        Buscar
      </button>
    </form>

      {/* Si errorFetch es true, mostramos un mensaje de error al usuario */}
      {errorFetch && (
        <div className="alert alert-danger" role="alert">
          No se ha podido establecer la conexión con el recurso solicitado
        </div>
      )}
      {/* Si el status devuelto es un 200, es que sí se han encontrado los datos */}
      {status === 200 && (
          <div className="row">
            {/* Iteramos los paises y por cada uno sacamos un card */}
            {coctelesDeGinebra?.map((x) => (
                <CardCoctel strDrink={x.strDrink} strDrinkThumb={x.strDrinkThumb}  key={x.idDrink}></CardCoctel>
                ))}
          </div>
      )}
    </>
  );
};
