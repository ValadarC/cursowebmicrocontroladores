import React from 'react';
import ReactDOM from 'react-dom/client';
import { CoctelesForm } from './CoctelesForm.tsx';
import 'bootstrap/dist/css/bootstrap.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <CoctelesForm />
  </React.StrictMode>,
)
