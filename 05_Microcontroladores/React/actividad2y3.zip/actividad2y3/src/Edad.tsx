import { ChangeEvent, useState } from "react";
import { INombre } from "./interfaces/nombre.interface";

export const Edad = () => {
    const [laEdad, setLaEdad] = useState(0);

    const nombres: INombre[]= [
        {
            nombre:'Pedro',
            edad: 25
        },
        {
            nombre:'Ana',
            edad: 15
        },
        {
            nombre:'Marta',
            edad: 28
        },
        {
            nombre:'Juan',
            edad: 45
        }
    ];

    const comprobarEdad = (e: ChangeEvent<HTMLInputElement>) =>{
        setLaEdad(Number(e.target.value))
    }

    return(
        <>
            <div className="container mt-5">
                <input placeholder="Introduce una edad" autoFocus style={{padding:5}} type="number" onChange={comprobarEdad}/>
                <p>{laEdad >= 18 ? 'Es mayor de edad' : 'No es mayor de edad'}</p>
       
                <ul>
                    {nombres.map((x,i) => (
                        <li key={i}>
                            {x.nombre} - {x.edad}- 
                            {x.edad >= 18 ? 'Es mayor de edad' : 'No es mayor de edad'}
                        </li>
                    ))}
                </ul>
            </div>
        </>
      

        
    )
}