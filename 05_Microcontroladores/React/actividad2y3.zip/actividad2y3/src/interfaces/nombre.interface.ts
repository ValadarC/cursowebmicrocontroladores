export interface INombre {
    nombre:string;
    edad:number;
}