export interface ICoctel{
    drinks:IDrink[];
}
export interface IDrink {
    strDrink:      string;
    strDrinkThumb: string;
    idDrink?:       string;
}
