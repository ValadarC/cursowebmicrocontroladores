import { Navigate, Route, Routes } from 'react-router-dom';
import { HomePage } from '../pages/HomePage';
import { PaisesPage } from '../pages/PaisesPage';
import { ErrorPage } from '../pages/ErrorPage';
import { Navbar } from '../components/Navbar';

export const AppRouter = () => {
  return (
    <>
      <Navbar/>
      <Routes>
        <Route path="/" element={<Navigate to="home" />} />
        <Route path="home" element={<HomePage />} />
        <Route path="paises" element={<PaisesPage />} />
        <Route path="*" element={<ErrorPage />} />
      </Routes>
    </>
  );
};
