export const HomePage = () => {
    return (
      <>
        <h1>SPA hecha con React utilizando PrimeReact</h1>
        <hr />
        <img
          src="https://miro.medium.com/v2/resize:fit:1400/1*aT7oVaUntkAQpWXTfkuKyA.png"
          alt="logo"
          className="img-fluid"
        />
        <hr />
        <h4>Autor: Juan Luis</h4>
      </>
    );
  };