export const ErrorPage = () => {
    return (
      <>
        <h1>Recurso no encontrado</h1>
        <img src="https://dinahosting.com/blog/upload/2020/07/eror-404.jpg" alt="imagen error" className="img-fluid" />
      </>
    );
  };
  
  