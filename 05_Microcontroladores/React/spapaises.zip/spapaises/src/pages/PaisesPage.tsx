import { useEffect, useState } from 'react';
import { DataTable } from 'primereact/datatable';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { IPais } from '../interfaces/pais.interface';

export const PaisesPage = () => {
  const [paises, setPaises] = useState<IPais[]>([]);
  const [flag, setFlag] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [errorFetch, setErrorFetch] = useState<boolean>(false);

  const fetchPaises = async (): Promise<void> => {
    try {
      setLoading(true);
      const data = await fetch(`https://restcountries.com/v3.1/all`);
      const json: IPais[] = await data.json();
      setPaises(json);
      setErrorFetch(false);
      setLoading(false);
    } catch (e) {
      setLoading(false);
      setErrorFetch(true);
    }
  };

  useEffect(() => {
    fetchPaises();
  }, []);

  // PrimeReact datatable

  // Plantilla para dibujar la bandera. La clase flag está en el archivo index.css.
  // Recibimos el objeto del país
  // Se retorna una imagen de la bandera aplicando la clase css flag
  const flagTemplate = (pais: IPais) => {
    return <img src={pais.flags.png} alt={pais.name.common} className="flag" />;
  };

  // Plantilla para renderizar los habitantes
  // Recibimos el objeto del país
  // Retornamos un string con los puntos de miles sin decimales.
  // El undefined es porque no estamos incluyendo ningún idioma a aplicar
  const populationTemplate = (pais: IPais) => {
    return <span>{pais.population.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>;
  };

  // Plantilla para renderizar los habitantes
  // Recibimos el objeto del país
  // La capital viene como un array. Algunos países no tienen capital y vienen con su valor a nulo.
  //{pais.capital && pais.capital[0]} saca el primer valor del array de capitales si es que hay un array
  const capitalTemplate = (pais: IPais) => {
    return <span>{pais.capital && pais.capital[0]}</span>;
  };

  // Esta función es llamada por un botón a la derecha de cada país.
  // Actualiza mediante el useState el string flag que es la url de la bandera
  // Gracias a esta función, la bandera se verá a la derecha más grande
  const showBigFlag = (pais: IPais) => {
    setFlag(pais.flags.png);
  };

  // Plantlla para dibujar el botón que nos va a permitir ver la bandera
  // Devuelve un botón con un icono de prime icons, una clase bootstrap para que el botón salga con forma circular y con el evento click configurado para ejecutar la función showBigFlag pasando el país como argumento
  const actionBodyTemplate = (pais: IPais) => {
    return (
      <>
        <Button
          icon="pi pi-flag"
          severity="success"
          rounded
          onClick={() => showBigFlag(pais)}
        />
      </>
    );
  };
  return (
    <>
      <h1>Países del mundo con tabla PrimeReact</h1>
      <hr />
      <div className="row">
        {errorFetch && (
          <div className="alert alert-danger" role="alert">
            No se ha podido establecer la conexión con la API
          </div>
        )}

        <div className="col-8">
          {/* value es la propiedad donde especificaremos la colección de datos a visualizar (paises). paginator es para que salgan de forma automática los botones de desplazamiento
          loading hace aparecer un spinner de espera en la propia tabla. Aprovechamos el loading de nuestro hook useFetch para gestionar esto.
          paginaTorTemplate permite detallar qué botones de desplazamiento queremos ver. Hemos puesto algunos que aparecen en la documentación del componente
          rows son las filas que vemos por página. rowsPerPageOptions nos permite hacer un cambio de filas por página en un desplegable. */}
          <DataTable
            value={paises}
            paginator
            stripedRows 
            loading={loading}
            paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
            currentPageReportTemplate="{first} de {last} de un total de {totalRecords}"
            rows={10}
            rowsPerPageOptions={[10, 20, 50]}
          >
            {/* Aquí elegimos las columnas (Columns) que queremos ver */}
            {/* La primera columna es la bandera dibujada mediante la plantilla flagTemplate. No ponemos cabecera porque es una imagen */}
            <Column header="" field="flag.png" body={flagTemplate}></Column>
            {/* Segunda columna. El nombre del país. Gracias a filter y sortable, podemos incluir una opción de filtrado automático y una opción de ordenación al pulsar en la cabecera */}
            <Column field="name.common" header="Nombre" filter filterPlaceholder="Buscar" sortable></Column>
            {/* La tercera columna es la capital renderizada dibujada mediante la plantilla capitalTemplate. */}
            <Column field="capital" header="Capital" body={capitalTemplate} sortable></Column>
            {/* La cuarta columna son los habitantes renderizados dibujados mediante la plantilla populationTemplate.  Incluimos un estilo de alineación por la derecha*/}
            <Column field="population" header="Habitantes" body={populationTemplate} sortable style={{ textAlign: 'right' }}></Column>
            {/* Esta es la columna del botón. Se dibuja mediante la plantilla actionBodyTemplate*/}
            <Column body={actionBodyTemplate}></Column>
          </DataTable>
        </div>
        {/* Este div es para dibujar la bandera grande. Gracias al botón se ejecuta una función que cambia el string flag que es el que aquí se utiliza */}
        <div className="col">{flag && <img src={flag} alt="bandera" className="img-fluid" />}</div>
      </div>
    </>
  );
};