
import React from 'react';
import ReactDOM from 'react-dom/client';
import { ProductosPage } from './ProductosPage';
import 'bootstrap/dist/css/bootstrap.min.css';

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <ProductosPage />
  </React.StrictMode>
);
