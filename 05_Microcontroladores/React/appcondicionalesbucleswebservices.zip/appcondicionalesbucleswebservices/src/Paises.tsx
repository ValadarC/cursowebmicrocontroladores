import { useState } from 'react';
import { IPais } from './interfaces/pais.interface';

export const Paises = () => {
    const [paises, setPaises] = useState<IPais[]>([]); //useState para gestionar cambios de estado en los países que vienen de la API Rest Countries
    const [status, setStatus] = useState<number>(0); //useState para gestionar cambios de estado en el status (202 o 404) que devuelve la API Rest Countries
    const [errorFetch, setErrorFetch] = useState<boolean>(false); // useState para getionar cambios de estado en el error que puede producir fetch
    // fetch puede producir el error cuando hay error de conexión o cuando apuntamos a un dominio o a un archivo inexistente. Si la api devuelve un error como el 404 o el 401, no va al catch. Devuelve un status con el código de error

    // Función para obtener los países de la API Rest Countries.
    // Es una promesa que no retorna nada (Promise<void>)
    const fetchPaises = async (): Promise<void> => {
        try {
            const data = await fetch(`https://restcountries.com/v3.1/all`);
            const json: IPais[] = await data.json();
            setStatus(data.status);
            setPaises(json);
            setErrorFetch(false);
        } catch (e) {
            setErrorFetch(true);
        }
    };

    return (
        <>
            <h1>Datos de países del mundo</h1>
            <hr />
            <button className="btn btn-success" type="button" onClick={fetchPaises}>
                Obtener información
            </button>

            <hr />

            {/* Si errorFetch es true, mostramos un mensaje de error al usuario */}
            {!errorFetch && (
                <div className="alert alert-danger" role="alert">
                    No se ha podido establecer la conexión con el recurso solicitado
                </div>
            )}
            {/* Si el status devuelto es un 200, es que sí se han encontrado los datos */}
            {status === 200 && (
                <div>
                    <div className="row">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th scope="col">País</th>
                                    <th scope="col">Habitantes</th>
                                    <th scope="col">Capital</th>
                                </tr>
                            </thead>
                            <tbody>
                                {paises.map((x) => (
                                    <tr>
                                        <td>{x.name.common}</td>
                                        <td>{x.population}</td>
                                        <td>{x.capital && x.capital[0]}</td>
                                    </tr>
                                ))}
                            </tbody>

                        </table>
                        {/* Iteramos los paises y por cada uno sacamos un card */}
                        {/* // {paises.map((x) => (

            //   <div className="col" key={x.name.common}>
            //     <div className="card" style={{ width: '18rem' }}>
            //       <img src={x.flags.png} className="card-img-top bordered" alt={'Bandera de ' + x.name.common} />
            //       <div className="card-body">
            //         <h5 className="card-title">{x.name.common}</h5>
            //         <p className="card-text">{x.capital && x.capital[0]}</p>
            //       </div>
            //     </div>
            //   </div>
            ))} */}
                    </div>
                </div>
            )}
        </>
    );
};

