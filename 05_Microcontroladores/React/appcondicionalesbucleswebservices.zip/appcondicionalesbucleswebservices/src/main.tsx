import React from 'react';
import ReactDOM from 'react-dom/client';
// import { Paises } from './Paises';

import 'bootstrap/dist/css/bootstrap.css';
import { Paises } from './Paises';

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <Paises />
  </React.StrictMode>
);