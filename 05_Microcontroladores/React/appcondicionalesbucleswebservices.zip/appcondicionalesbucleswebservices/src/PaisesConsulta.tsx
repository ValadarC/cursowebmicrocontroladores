import { ChangeEvent, useEffect, useState } from 'react';
import { IPais } from './interfaces/pais.interface';
import { ComponenteCardPais } from './components/ComponenteCardPais';

export const PaisesConsulta = () => {
  const [paises, setPaises] = useState<IPais[]>([]); //useState para gestionar cambios de estado en los países que vienen de la API Rest Countries
  const [status, setStatus] = useState<number>(0); //useState para gestionar cambios de estado en el status (202 o 404) que devuelve la API Rest Countries
  const [paisConsulta, setPaisConsulta] = useState<IPais | undefined>(undefined); //useState para gestionar cambios de estado en el país que buscamos según el país que hemos introducido en el input
  const [pais, setPais] = useState<string>(''); //useState para gestionar cambios de estado en el input donde vamos a escribir el país a consultar
  const [errorFetch, setErrorFetch] = useState<boolean>(false); // useState para getionar cambios de estado en el error que puede producir fetch
  // fetch puede producir el error cuando hay error de conexión o cuando apuntamos a un dominio o a un archivo inexistente. Si la api devuelve un error como el 404 o el 401, no va al catch. Devuelve un status con el código de error

  // Función para obtener los países de la API Rest Countries.
  // Es una promesa que no retorna nada (Promise<void>)
  const fetchPaises = async (): Promise<void> => {
    try {
      const data = await fetch(`https://restcountries.com/v3.1/all`);
      const json: IPais[] = await data.json();
      setStatus(data.status);
      setPaises(json);
      setErrorFetch(false);
    } catch (e) {
      setErrorFetch(true);
    }
  };

  // Si llamamos aquí a fetchPaises, se produce un bucle infinito porque cada vez que hay un cambio de estado en el país, se renderiza el componente y la función se ejecuta
  // Por lo tanto, nunca debemos llamar a una función directamente en React.
  // fetchPaises();

  // El hook useEffect permite ejecutar algo la primera vez que se carga el componente o cuando cambie uno o varios valores en concreto. Ese valor o valores va en un array de dependencias que se registra cuando se cierra useEffect
  useEffect(() => {
    fetchPaises();
  }, []); // Este es el array de dependencias de useEffect. Si ponemos un array vacío, lo que está dentro de useEffect se ejecuta solo la primera vez que el componente se carga.

  const cambioPais = (e: ChangeEvent<HTMLInputElement>): void => {
    setPais(e.target.value);
    setPaisConsulta(paises.find((x) => x.name.common.toLowerCase() === e.target.value.toLowerCase()));
  };

  return (
    <>
      <h1>Datos de países del mundo</h1>
      <hr />

      <div className="form-group">
        <label htmlFor="pais">Introduce uno de los países</label>
        <input type="text" id="pais" className="form-control" value={pais} onChange={cambioPais} />
      </div>

      {/* Solo sacamos el pais consultado si lo hemos encontrado  */}
      {paisConsulta && (
        <div className="row">
          <ComponenteCardPais pais={paisConsulta}/>
        </div>
      )}

      <hr />
      {/* Si errorFetch es true, mostramos un mensaje de error al usuario */}
      {errorFetch && (
        <div className="alert alert-danger" role="alert">
          No se ha podido establecer la conexión con el recurso solicitado
        </div>
      )}
      {/* Si el status devuelto es un 200, es que sí se han encontrado los datos */}
      {status === 200 && (
          <div className="row">
            {/* Iteramos los paises y por cada uno sacamos un card */}
            {paises.map((x) => (
                <ComponenteCardPais pais={x} key="x-name.common"/>
            ))}
          </div>
      )}
    </>
  );
};
