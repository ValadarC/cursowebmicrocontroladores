import { ChangeEvent, useState } from 'react';

interface ICarrito {
  codigo: number;
  nombre: string;
  precio: number;
}

export const CondicionalesBucles = () => {
  const [numero, setNumero] = useState<number>(0);
  const nombres: string[] = ['Ana', 'Juan', 'Marta'];
  const carrito: ICarrito[] = [
    {
      codigo: 1,
      nombre: 'Teclado',
      precio: 20
    },
    {
      codigo: 2,
      nombre: 'Ratón',
      precio: 15
    },
    {
      codigo: 3,
      nombre: 'Portátil',
      precio: 800
    }
  ];

  const cambioNumero = (e: ChangeEvent<HTMLInputElement>): void => {
    setNumero(Number(e.target.value));
  };

  return (
    <>
      <h1>Condicionales y bucles</h1>
      <hr />
      <div className="form-group">
        <label htmlFor="numero">Introduce número</label>
        <input type="number" className="form-control" onChange={cambioNumero} id="numero" />
      </div>
      <h2>Número: {numero}</h2>
      {/* Condicionales */}
      {/* En React, gracias a JSX, se pueden generar elementos dinámicamente de acuerdo a una lógica. Esa lógica debe ir entre llaves */}
      {/* En el siguiente ejemplo, mediante un if ternario, dentro de un párrafo evaluamos el número % 2 para ver si procede sacar el mensaje 'es par' o 'es 'impar'*/}
      <p>{numero % 2 === 0 ? 'es par' : 'es impar'}</p>
      {/* En este otro ejemplo hacemos lo mismo, pero comenzamos con la expresión para que cuando sea cierta genere un párrafo y si no otro*/}
      {numero % 2 === 0 ? <p>es par</p> : <p>es impar</p>}
      {/* En este otro ejemplo se hace lo mismo, pero sacando un HTML más extenso. En estos casos, aunque no es obligatorio, el HTML que se devuelve va entre paréntesis*/}
      {numero % 2 === 0 ? (
        <div>
          <p>El número introducido</p>
          <p>es par</p>
        </div>
      ) : (
        <div>
          <p>El número introducido</p>
          <p>es impar</p>
        </div>
      )}
      {/* En este otro ejemplo se hace lo mismo, pero con un ternario sin else. Si el numero % 2 da 0, después de && generamos el HTML deseado. Aquí son varias líneas*/}
      {numero % 2 === 0 && (
        <div>
          <p>El número introducido</p>
          <p>es par</p>
        </div>
      )}
      {/* Y aquí solo es una línea*/}
      {numero % 2 !== 0 && <p>es impar</p>}

      {/* En React, gracias a JSX, se pueden construir elementos dinámicamente de acuerdo al contenido de arrays. Esta generación se pone entre llaves y para ello utilizamos el método map */}
      {/* Aquí iteramos el array de nombres que hemos definido arriba. map devuelve otro array. En este caso, gracias a JSX y a map, podemos construir un párrafo por cada nombre. Algo así como un array de párrafos */}
      {/* En React, cuando generamos elementos mediante map, debemos dar a cada uno un key. Esto le sirve a React para identificar cada elemento en su DOM virtual. Es una especificación de obligado cumplimiento */}
      {/* El valor del key debe ser único. En este caso, el valor del propio nombre lo es, pero si habría personas con el mismo nombre daría error */}
      {nombres.map((x) => (
        <p key={x}>{x}</p>
      ))}

      {/* Aquí generamos un HTML algo más extenso porque queremos mostrar el carrito, pero el método es el mismo. Aprovechamos algo único como el código para dar ese valor al key */}
      <ul>
        {carrito.map((x) => (
          <li key={x.codigo}>
            {x.nombre} - {x.precio} 
          </li>
        ))}
      </ul>

      {/* Este ejemplo repite la funcionalidad anterior usando desestructuración */}
      <ul>
        {carrito.map(({ codigo, nombre, precio }) => (
          <li key={codigo}>
            {nombre} - {precio}
          </li>
        ))}
      </ul>
    </>
  );
};
