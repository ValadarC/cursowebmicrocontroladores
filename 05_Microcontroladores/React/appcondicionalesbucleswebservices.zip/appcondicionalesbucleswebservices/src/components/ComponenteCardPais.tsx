import { IPais } from '../interfaces/pais.interface';

// Esta interface determina el tipado de la información que va a recibir el componente. En este caso, recibe un objeto país y lo renderiza.
// Se decide poner aquí y no en la carpeta interfaces porque su uso va a ser exclusivo para este componente.
interface IComponenteCardPaisProps {
  pais: IPais;
}

// El componente recibe los países y los renderiza
export const ComponenteCardPais = ({ pais }: IComponenteCardPaisProps) => {
  return (
    <>
      <div className="col">
        <div className="card">
          <img
            className="card-img-top"
            src={pais.flags.png}
            alt={'Bandera de' + pais.name.common}
            style={{ width: '18rem' }}
          />
          <div className="card-body">
            <h5 className="card-title">{pais.name.common}</h5>
            <p className="card-text">Capital: {pais.capital && pais.capital[0]}</p>
          </div>
        </div>
      </div>
    </>
  );
}