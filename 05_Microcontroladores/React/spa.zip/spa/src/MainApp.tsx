import { AppRouter } from './router/AppRouter';

export const MainApp = () => {
  return (
    <>
      <AppRouter />
    </>
  );
};