export const HomePage = () => {
    return (
      <>
        <h1>SPA hecha con React</h1>
        <hr />
        <h2>Autor: Juan Luis</h2>
      </>
    );
};