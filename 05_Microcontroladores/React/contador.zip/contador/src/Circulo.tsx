import { ChangeEvent, useState } from 'react';

interface IPropiedades {
  valor: number;
}

export const Circulo = ({ valor }: IPropiedades) => {
  const [radio, setRadio] = useState<number>(valor);
  const cambioRadio = (e: ChangeEvent<HTMLInputElement>): void => {
    console.log(e);
    setRadio(Number(e.target.value));
  };

  return (
    <>
      <h1>Circulo</h1>
      <input type="number" onChange={cambioRadio} />
      <h2>Radio: {radio}</h2>
      <h2>Área: {Math.PI * (radio * radio)}</h2>
    </>
  );
};