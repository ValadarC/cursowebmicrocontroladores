import { useState } from 'react';

interface IPropiedades {
  valor: number;
}

export const Contador = ({ valor }: IPropiedades) => {
  // useState es un hook.
  // Un hook es una función ya hecha en React
  // Le pasamos el valor inicial (valor).
  // Devuelve un array de dos posiciones. Mediante la desestructuración de arrays los podemos conseguir [ contador, setcontador ]
  // contador es el nombre que le damos a la variable que está en el state
  // setContador es el nombre de la función que vamos a usar para manejar el contador
  // Cuando se ejecuta el setcontador automáticamente cambia el contador y esto provoca la renderización de la página en las partes donde el contador tiene efecto

  const [contador, setContador] = useState<number>(valor); //hook
  console.log(contador);
  console.log(setContador);

  // Eventos en React:  https://es.reactjs.org/docs/events.html

  // El evento onClick pasa las referencias a las funciones
  const sumar = (): void => {
    //  setcontador( contador ++); // Error porque no podemos cambiar el valor de contador. React nos obliga a no mutar el state de esta manera
    setContador(contador + 1);
  };

  const restar = (): void  => setContador(contador - 1);

  const reset = (): void  => setContador(valor);

  return (
    <>
      <h1>Contador</h1>
      <h2> {contador} </h2>
      {/* No hay que poner handleAdd() porque si no se ejecuta de forma inmediata. Hay que pasar la referencia a la función */}
      <button onClick={sumar}>+1</button>
      <button onClick={reset}>Reset</button>
      <button disabled={contador === 0} onClick={restar}>
        -1
      </button>
    </>
  );
};