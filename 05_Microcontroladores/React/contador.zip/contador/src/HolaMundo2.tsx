// En React, un componente no puede devolver unos elementos HTML que no estén en un contenedor
// Podríamos devolver un div con elementos dentro, pero eso renderiza un div, que igual por temas de estilos no nos interesa
// Para eso, React desarrolló el Fragment. Se puede hacer así (poco común)
// import { Fragment } from 'react';

// export const App = (): JSX.Element => {
//   return (
//     <Fragment>
//       <h1>Hola Mundo</h1>
//     </Fragment>
//   );
// };

// O así (más elegante)

export const App = (): JSX.Element => {
    return (
      <>
        <h1>Hola Mundo</h1>
        <p>Código realizado por Juan Luis</p>
      </>
    );
  };