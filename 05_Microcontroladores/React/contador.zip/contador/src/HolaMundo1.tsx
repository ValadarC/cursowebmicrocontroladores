export const App = (): JSX.Element => {
    return <h1>Hola Mundo</h1>;
};

// const App = (): JSX.Element => {
//     return <h1>Hola Mundo</h1>;
// };

// export default App;