interface IInformacion {
  profesion: string;
  localidad: string;
}

// React permite visualizar valores de variables o constantes en el código HTML del componente
// Esos valores van entre llaves. En realidad, podemos poner entre llaves una expresión JavaScript. Por ejemplo, {1+1} devolvería 2
// interface para dar tipo a los parámetros que recibe la función
// El saludo es obligatorio y la despedida opcional
interface IPropiedades {
  saludo: string;
  despedida?: string;
}

// Recibimos las propiedades (en React props) y las desestructuramos porque React las manda como un objeto
// Luego las ponemos entre llaves en el código HTML para utilizarlas
export const App = ({ saludo, despedida = 'Adiós' }: IPropiedades): JSX.Element => {
  const autor: string = 'Juan Luis';
  const info: IInformacion = {
    profesion: 'Desarrollador',
    localidad: 'Pamplona'
  };

  const hoy = (): string => {
    return new Date().toLocaleDateString();
  };
  
  return (
    <>
      <h1>{saludo}</h1>
      <p>
        Código realizado por {autor}, {info.profesion} residente en {info.localidad}
      </p>
      <p>{hoy()}</p>
      <h2>{despedida}</h2>
    </>
  );
};
