interface IInformacion {
    profesion: string;
    localidad: string;
}
  
// React permite visualizar valores de variables o constantes en el código HTML del componente
// Esos valores van entre llaves. En realidad, podemos poner entre llaves una expresión JavaScript. Por ejemplo, {1+1} devolvería 2
export const App = (): JSX.Element => {
    const autor: string = 'Juan Luis';
    const info: IInformacion = {
        profesion: 'Desarrollador',
        localidad: 'Pamplona'
    };
    
    const hoy = (): string => {
        return new Date().toLocaleDateString();
    };

    return (
        <>
            <h1>Hola mundo</h1>
            <p>
                Código realizado por {autor}, {info.profesion} residente en {info.localidad}
            </p>
            <p>{hoy()}</p>
        </>
    );
};