import React from 'react';
import ReactDOM from 'react-dom/client';
// import { App } from './HolaMundo4';
import './styles.css';
import { Circulo } from './Circulo';
//import { Contador } from './Contador';

ReactDOM.createRoot(document.querySelector('#root')!).render(
  // StrictMode no representa ningún elemento visible en el DOM en el modo de desarrollo, pero habilita las comprobaciones y da advertencias para los elementos descendientes
  // saludo y despedida son propiedades (en React props) que se le pasan al componente
  <React.StrictMode>
    {/* <App saludo="Hola mundo" despedida='Hasta luego'/> */}
   {/* <Contador valor={0}/> */}
   <Circulo valor={1}/>
  </React.StrictMode>
);
