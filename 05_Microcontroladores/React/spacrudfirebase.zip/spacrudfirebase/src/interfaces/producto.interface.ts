export interface IProducto {
    id?: string;
    nombre: string;
    precio: number;
}
  