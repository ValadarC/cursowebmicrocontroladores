import { useState } from 'react';
import { ProductosForm } from './ProductosForm';
import { ProductosTable } from './ProductosTable';
import { IProducto } from '../../interfaces/producto.interface';

export const ProductosPage = () => {
  const [refreshProductos, setRefreshProductos] = useState<boolean>(true);
  const [producto, setProducto] = useState<IProducto>({
    id: '',
    nombre: '',
    precio: 0
  });
  const [edit, setEdit] = useState<boolean>(false);

  return (
    <>
      <h1>Firebase-Colección productos</h1>
      <hr />
      <div className="row">
        <div className="col">
          <ProductosForm setRefreshProductos={setRefreshProductos} setEdit={setEdit} edit={edit} producto={producto} />
        </div>
        <div className="col">
          <ProductosTable
            refreshProductos={refreshProductos}
            setRefreshProductos={setRefreshProductos}
            setEdit={setEdit}
            setProducto={setProducto}
          />
        </div>
      </div>
    </>
  );
};
