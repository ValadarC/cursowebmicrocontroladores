import { DocumentData, QueryDocumentSnapshot, collection, deleteDoc, doc, getDocs } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import { db } from '../../firebase/firebaseConfig';
import { IProducto } from '../../interfaces/producto.interface';

interface IProductosTableProps {
  refreshProductos: boolean;
  setEdit: React.Dispatch<React.SetStateAction<boolean>>;
  setProducto: React.Dispatch<React.SetStateAction<IProducto>>;
  setRefreshProductos: React.Dispatch<React.SetStateAction<boolean>>;
}

export const ProductosTable = ({
  refreshProductos,
  setEdit,
  setProducto,
  setRefreshProductos
}: IProductosTableProps) => {
  const [productos, setProductos] = useState<QueryDocumentSnapshot<DocumentData>[]>([]);

  useEffect(() => {
    if (refreshProductos) {
      getProductos();
    }
  }, [refreshProductos]);

  const getProductos = async () => {
    const productos = await getDocs(collection(db, 'productos'));
    setProductos(productos.docs);
    setRefreshProductos(false);
    const productoEdit: IProducto = {
      id: '',
      nombre: '',
      precio: 0
    };
    setProducto(productoEdit);
    setEdit(false);
  };

  const editProducto = (producto: DocumentData) => {
    const productoEdit: IProducto = {
      id: producto.id,
      nombre: producto.data().nombre,
      precio: producto.data().precio
    };
    setProducto(productoEdit);
    setEdit(true);
  };

  const deleteProducto = async (producto: DocumentData) => {
    if (window.confirm(`¿Estás seguro de eliminar ${producto.data().nombre}?`)) {
      const productoEliminar = doc(db, `productos/${producto.id}`);
      await deleteDoc(productoEliminar);
      setRefreshProductos(true);
    }
  };

  return (
    <>
      <h2>Tabla de productos</h2>
      <hr />
      {refreshProductos && (
        <div className="spinner-border" role="status">
          <span className="sr-only">Cargando productos...</span>
        </div>
      )}
      {productos?.length > 0 && (
        <>
          <h2>Total productos: {productos.length}</h2>
          <table className="table">
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Precio</th>
              </tr>
            </thead>
            <tbody>
              {productos.map((x) => (
                <tr key={x.id}>
                  <td>{x.data().nombre}</td>
                  <td>{x.data().precio}</td>
                  <td>
                    <button className="btn btn-warning" onClick={() => editProducto(x)}>
                      Modificar
                    </button>
                  </td>
                  <td>
                    <button className="btn btn-danger" onClick={() => deleteProducto(x)}>
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
    </>
  );
};



