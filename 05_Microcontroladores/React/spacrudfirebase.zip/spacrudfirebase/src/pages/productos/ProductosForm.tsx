import { ChangeEvent, FormEvent, useEffect, useState } from 'react';
import { IProducto } from '../../interfaces/producto.interface';
import { addDoc, collection, doc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase/firebaseConfig';

interface IProductosFormProps {
  setRefreshProductos: React.Dispatch<React.SetStateAction<boolean>>;
  setEdit: React.Dispatch<React.SetStateAction<boolean>>;
  edit: boolean;
  producto: IProducto;
}

export const ProductosForm = ({ setRefreshProductos, setEdit, edit, producto }: IProductosFormProps) => {
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [form, setForm] = useState<IProducto>({
    id: producto.id,
    nombre: producto.nombre,
    precio: producto.precio
  });

  const { nombre, precio } = form;

  useEffect(() => {
    setForm(producto);
  }, [producto]);

  const onInputChange = ({ target }: ChangeEvent<HTMLInputElement>) => {
    console.log(target);
    const { id, value } = target;
    setForm({
      ...form,
      [id]: value
    });
  };

  const resetForm = () => {
    setForm({
      nombre: '',
      precio: 0
    });
    setEdit(false);
  };

  const saveProducto = async (e: FormEvent) => {
    e.preventDefault();
    if (edit) {
      const productoActualizar = doc(db, `productos/${producto.id}`);
      try {
        await setDoc(productoActualizar, {
          nombre: nombre,
          precio: Number(precio)
        });
        setRefreshProductos(true);
        setErrorMsg(null);
      } catch (error) {
        setErrorMsg('Error en la actualización del producto');
      }
    } else {
      try {
        await addDoc(collection(db, 'productos'), {
          nombre: nombre,
          precio: Number(precio)
        });
        setRefreshProductos(true);
        setErrorMsg(null);
      } catch (error) {
        setErrorMsg('Error en la inserción del producto');
      }
    }
  };

  const cancelarEdicion = () => {
    resetForm();
  };

  return (
    <>
      <h2>Formulario de productos</h2>
      <hr />
      <form onSubmit={saveProducto}>
        <div className="form-group">
          <label className="form-label" htmlFor="nombre">
            Nombre
          </label>
          <input id="nombre" type="text" className="form-control" value={nombre} onChange={onInputChange} required />
        </div>
        <div className="form-group">
          <label className="form-label" htmlFor="precio">
            Precio
          </label>
          <input id="precio" type="number" className="form-control" value={precio} onChange={onInputChange} required />
        </div>

        {/* El botón Cancelar edición solo aparece cuando edit es true */}
        {edit && (
          <button type="button" className="btn btn-secondary mt-2" onClick={cancelarEdicion}>
            Cancelar edición
          </button>
        )}
        <button type="submit" className="btn btn-primary mt-2">
          {edit ? 'Actualizar' : 'Agregar'}
        </button>
      </form>
      {errorMsg && (
        <div className="alert alert-danger" role="alert">
          {errorMsg}
        </div>
      )}
    </>
  );
};
