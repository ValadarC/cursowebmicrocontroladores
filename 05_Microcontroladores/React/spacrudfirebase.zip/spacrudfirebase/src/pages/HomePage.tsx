export const HomePage = () => {
    return (
      <>
        <h1>SPA hecha con React. Operaciones CRUD con Firebase</h1>
        <hr />
        <img
          src="https://miro.medium.com/v2/resize:fit:1358/1*U3zzYALI90kjVHmPGJWqnw.png"
          alt="logos"
          className="img-fluid"
        />
        <hr />
        <h4>Autor: Juan Luis</h4>
      </>
    );
  };