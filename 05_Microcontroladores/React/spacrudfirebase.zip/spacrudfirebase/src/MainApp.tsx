import { AppRouter } from './router/AppRouter';

export const MainApp = () => {
  return (
    <>
      <div className="container">
        <AppRouter />
      </div>
    </>
  );
};