import { Navigate, Route, Routes } from 'react-router-dom';
import { HomePage } from '../pages/HomePage';
import { ErrorPage } from '../pages/ErrorPage';
import { ProductosPage } from '../pages/productos/ProductosPage';
import { Navbar } from '../components/Navbar';

export const AppRouter = () => {
  return (
    <>
      <Navbar/>
      <Routes>
        <Route path="/" element={<Navigate to="home" />} />
        <Route path="home" element={<HomePage />} />
        <Route path="productos" element={<ProductosPage />} />
        <Route path="*" element={<ErrorPage />} />
      </Routes>
    </>
  );
};