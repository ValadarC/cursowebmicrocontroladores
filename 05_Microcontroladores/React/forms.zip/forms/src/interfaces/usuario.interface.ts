export interface IUsuario {
  email: string;
  password: string;
}
