import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { getCategorias, getChisteAleatorio, getChisteDeCategoria } 
  from './controllers/chuckController';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(express.static('public'));

app.use(cors());
app.use(express.json());

app.get('/api/chuck/random', getChisteAleatorio);
app.get('/api/chuck/categorias', getCategorias);
app.get('/api/chuck/chiste/categoria/:categoria', getChisteDeCategoria);

app.listen(port, () => {
  console.log('Servidor en ejecución en puerto ' + port);
});

