import axios from 'axios';
import { Request, Response } from 'express';
import { IChuck } from '../interfaces/chuck.interface';

// Urls para obtener un chiste aleatorio, todas las categorías de chistes y un chiste aleatorio de una categoría
// https://api.chucknorris.io/jokes/random
// https://api.chucknorris.io/jokes/categories
// https://api.chucknorris.io/jokes/random?category={category}

export const getChisteAleatorio = async (req: Request, res: Response) => {
  try {
    // axios({
    //   url: 'https://api.chucknorris.io/jokes/random',
    //   method: 'get'
    // });
    // Como ocurre con fetch, axios devuelve en una promesa la información. Por eso debemos preceder por await la petición y también precedemos la función por async
    const chiste = await axios.get<IChuck>('https://api.chucknorris.io/jokes/random');
    res.status(200).json(chiste.data);
    // Del resultado de la promesa extraemos el json (data)
    // unknown es un tipo de TypeScript parecido a any
    // const numero: any = 10;
    // const numero2: unknown =  10;
    // const string1: string = numero; // any se puede asignar a cualquier tipo de dato
    // const string2: string = numero2;// unknown no se puede asignar a cualquier tipo de dato
    // Para trabajar con tipado en el catch, o devuelve un unknown o un any
  } catch (error) {
    return error;
  }
};

export const getCategorias = async (req: Request, res: Response) => {
  try {
    const categorias = await axios.get<string[]>('https://api.chucknorris.io/jokes/categories');
    res.status(200).json(categorias.data);
  } catch (error) {
    return error;
  }
};

export const getChisteDeCategoria = async (req: Request, res: Response) => {
  const { categoria } = req.params;
  try {
    const chiste = await axios.get<IChuck>
    (`https://api.chucknorris.io/jokes/random?category=${categoria}`);
    res.status(200).json(chiste.data);
  } catch (error) {
    return error;
  }
};
