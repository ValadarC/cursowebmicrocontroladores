import express, { NextFunction } from 'express';
import { Request, Response, Express } from 'express';
// Instanciamos express
const app: Express = express();
const port = 3000;

// Middlewares
// Un middleware es una función que ejecuta cuando un servidor maneja una ruta. Esta función tiene acceso al objeto Request, Response y la función next().
// Request encapsula las características de la petición entrante, Response encapsula todo lo que Node puede realizar en cuanto a responder a esa petición y next permite ir a la función siguiente
// Las funciones middleware suelen ser utilizadas como mecanismos para verificar niveles de acceso antes de entrar en una ruta, manejo de errores, validación de datos, etc.

// En Express, los middlewares se especifican con la función use
// Como primer argumento recibimos el tipo de middleware que queremos implementar, la segunda (opcional) es una función de respuesta a ese middleware y la tercera (obligatoria si ponemos la segunda), el comando next
// que Express utilizará para ir al siguiente middleware

// Este middleware le dice a Express que la carpeta de contenido estático será la carpeta public
app.use(express.static('public'));

// Este middleware es igual al anterior, pero al tener una función de respuesta debemos especificar que vaya al siguiente middleware mediante next()
// Si no ponemos next(), nuestro servidor quedará bloqueado si intentamos ira a /api o a /api/json
// app.use(express.static('public'), (req: Request, res: Response, next: NextFunction) => {
//   //console.log('Entrando al middleware', req);
//   next();
// });

// Cuando se reciba una llamada a la raíz del sitio (get), respondemos
// req (es un alias) hace referencia a lo que el servidor recibe. Es un objeto de tipo Request
// res (es un alias) hace referencia al objeto que hace posible que el servidor responda. Es un objeto de tipo Response
app.get('/api', (req: Request, res: Response) => {
  res.send('<h1>Hola mundo</h1>');
});

app.get('/api/json', (req: Request, res: Response) => {
  res.json({
    nombre: 'Juan Luis',
    curso: 'Node'
  });
});

app.listen(port, () => {
  console.log(`Servidor en ejecución en puerto ${port}`);
});
